<div class="modal fade" id="detail-data-chart" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Detail Data Chart</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <i class="la la-lg la-times"></i> </button>
        </div>
        <div class="modal-body">
          

        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-white" data-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
</div>