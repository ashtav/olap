<script src="<?php echo e(asset('/assets/js/libraries/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/libraries/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/build/script.js')); ?>"></script>
<?php /**PATH /Applications/MAMP/htdocs/client/ppdp/resources/views/partials/script.blade.php ENDPATH**/ ?>