
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jq-3.3.1/dt-1.10.22/datatables.min.js"></script>

<script src="<?php echo e(asset('/assets/js/libraries/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/libraries/xlsx.full.min.js')); ?>"></script>


<script src="https://d3js.org/d3.v5.min.js"></script>
<script src="<?php echo e(asset('/assets/js/libraries/c3.min.js')); ?>"></script>
<script src="<?php echo e(asset('/assets/js/build/script.js')); ?>"></script>

<?php /**PATH /Applications/MAMP/htdocs/client/olap/resources/views/partials/script.blade.php ENDPATH**/ ?>