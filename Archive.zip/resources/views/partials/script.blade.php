{{-- <script src="{{asset('/assets/js/libraries/jquery-3.2.1.min.js')}}"></script> --}}
<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/jq-3.3.1/dt-1.10.22/datatables.min.js"></script>

<script src="{{asset('/assets/js/libraries/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('/assets/js/libraries/xlsx.full.min.js')}}"></script>
<script src="{{asset('/assets/js/build/script.js')}}"></script>

{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/vue/3.0.2/vue.cjs.js" integrity="sha512-tbfpVZegVjOUS9H3X526XZJxi/dPnhiGRM8Z83AY8kbFBrZLuug/mU57PJJsdXn38dlXjrUxtaEOl11Y1uoaRQ==" crossorigin="anonymous"></script> --}}